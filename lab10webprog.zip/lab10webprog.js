document.getElementById('dateForm').addEventListener('submit', function(event) {
  event.preventDefault();
  let date = document.getElementById('date').value;
  fetch(`https://colors.zoodinkers.com/api?date=${date}`)
    .then(response => response.json())
    .then(data => {
      let colorDisplay = document.getElementById('colorDisplay');
      let div = document.createElement('div');
      div.style.backgroundColor = data.hex;
      div.textContent = `Date: ${data.date}, Color: ${data.hex}`;
      colorDisplay.appendChild(div);

      let history = JSON.parse(localStorage.getItem('history')) || [];
      history.push({date: data.date, color: data.hex});
      localStorage.setItem('history', JSON.stringify(history));
    });
});

window.onload = function() {
  let history = JSON.parse(localStorage.getItem('history')) || [];
  let historyDiv = document.getElementById('history');
  for (let i = 0; i < history.length; i++) {
    let p = document.createElement('p');
    p.textContent = `Date: ${history[i].date}, Color: ${history[i].color}`;
    historyDiv.appendChild(p);
  }
};

document.getElementById('clearHistory').addEventListener('click', function() {
  localStorage.removeItem('history');
  document.getElementById('history').innerHTML = '';
});